@file:Depends("coreMindustry/utilNext", "调用菜单")
@file:Depends("coreMindustry/contentsTweaker", "修改核心单位,单位属性")
@file:Depends("wayzer/user/achievement", "成就")

package mapScript

import arc.Events
import arc.graphics.Color
import arc.graphics.Colors
import arc.math.Mathf
import arc.math.geom.Vec2
import arc.util.Time
import arc.util.Tmp
import coreLibrary.lib.util.loop
import coreLibrary.lib.with
import coreMindustry.lib.*
import mindustry.Vars
import mindustry.content.Blocks
import mindustry.content.Fx
import mindustry.content.Items
import mindustry.content.StatusEffects
import mindustry.core.World
import mindustry.entities.Damage
import mindustry.entities.Units
import mindustry.game.EventType
import mindustry.game.Team
import mindustry.gen.*
import mindustry.type.StatusEffect
import mindustry.world.Tile
import mindustry.world.blocks.campaign.Accelerator
import mindustry.world.blocks.campaign.LaunchPad
import mindustry.world.blocks.payloads.PayloadMassDriver
import mindustry.world.blocks.payloads.PayloadMassDriver.PayloadDriverBuild
import org.intellij.lang.annotations.Language
import wayzer.lib.dao.PlayerData
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**@author xkldklp
 * https://mdt.wayzer.top/v2/map/15450/latest
 */
name = "MagicFight"

val menu = contextScript<coreMindustry.UtilNext>()

val achievement = contextScript<wayzer.user.Achievement>()
fun Player.achievement(name: String, exp: Int) {
    val profile = PlayerData[uuid()].profile
    if (profile != null)
        achievement.finishAchievement(profile, name, exp, true)
}

val mode =
    when(Vars.state.rules.tags.getInt("mode", 0)) {
        0 -> "夺旗"
        else -> "夺旗"
    }

fun Float.format(i: Int = 2): String {
    return "%.${i}f".format(this)
}

fun Float.buildLineBar(length: Int = 20, max: Float = 20f, color: Pair<Pair<String, String>, String> = Pair(Pair("[yellow]","[green]"), "[red]")): String {
    val num = this
    return buildString {
        repeat(length) {
            append("${
                when {
                    num > it * (max / length) + max -> color.first.first
                    num > it * (max / length) -> color.first.second
                    else -> color.second
                }
            }|")
        }
    }
}

fun Int.buildLineBar(length: Int = 20, max: Int = 20, color: Pair<Pair<String, String>, String> = Pair(Pair("[yellow]","[green]"), "[red]")): String {
    return toFloat().buildLineBar(length, max.toFloat(), color)
}

val contentPatch
    @Language("JSON5")
    get() = """
{
  "unit": {
    "dagger.health": 100,
  },
  "block": {
    "core-shard": {
      "unitType": "dagger",
      "solid": false,
    },
    "core-foundation": {
      "unitType": "dagger",
      "solid": false,
    },
    "core-bastion": {
      "unitType": "dagger",
      "solid": false,
    },
    "core-nucleus": {
      "unitType": "dagger",
      "solid": false,
    },
    "core-citadel": {
      "unitType": "dagger",
      "solid": false,
    },
    "core-acropolis": {
      "unitType": "dagger",
      "solid": false,
    },
    "large-payload-mass-driver": {
      "solid": false,
    }
  }
}"""

data class SkillData(
    /** 体质 增加血量上限，每一级获得5额外血量 */
    var con: Int = 0,

    /** 敏捷 加快魔法冷却，每一级减少5% */
    var dex: Int = 0,

    /** 智力 减少魔法吟唱所需时间，每一级减少5% */
    var int: Int = 0,

    /** 意志 能够透支魔力且不受debuff，每一级额外透支10% */
    var pow: Int = 0,

    /** 魔力亲和 多回复1点魔力,魔力上限增加 20*/
    var affinity: Boolean = false
)

data class PlayerData(
    var skillPoint: Int = 10,
    var skillData: SkillData = SkillData(),
    val magicCores: MutableList<MagicCore> = mutableListOf(),
    var magicCore: MagicCore? = null,
    var mana: Float = 100f,
    var shootingStartTime: Long = 0,
    var cooldown: Long = 0,
    var level: Int = 1,
) {
    lateinit var player: Player

    val manaMax get() = 100f + if (skillData.affinity) 20f else 0f

    fun manaCheck(): Boolean {
        return mana < 0 - 100f * skillData.pow * 0.1f
    }

    fun chargeTime(): Int {
        return (magicCore!!.chargeTime() * (1 - (skillData.int * 0.05f + if (player.unit().hasEffect(StatusEffects.shielded)) player.unit().getDuration(StatusEffects.shielded) / 60f else 0f)) * (if (manaCheck()) 2f else 1f) * (if (Vars.state.teams.getActive().any { it.team.data.flagOn == player.unit() }) 2f else 1f)).toInt()
    }

    fun cooldown(): Int {
        return (magicCore!!.cooldown() * (1 - (skillData.int * 0.05f + if (player.unit().hasEffect(StatusEffects.shielded)) player.unit().getDuration(StatusEffects.shielded) / 60f else 0f)) * (if (manaCheck()) 3f else 1f) * (if (Vars.state.teams.getActive().any { it.team.data.flagOn == player.unit() }) 2f else 1f)).toInt()
    }

    fun manaCost(): Int {
        return (magicCore!!.manaCost() * (1 - (skillData.int * 0.05f + if (player.unit().hasEffect(StatusEffects.shielded)) player.unit().getDuration(StatusEffects.shielded) / 60f else 0f)) * if (manaCheck()) 0.25f else 1f).toInt()
    }

    /** 没有距离限制的魔法 返回 -1 */
    fun maxRange(): Float {
        return magicCore?.magicList?.maxOf {
            (it as? BlastMagic)?.range ?:
            (it as? BlinkMagic)?.length ?:
            -1f
        } ?: -1f
    }
}

val playerData by autoInit { mutableMapOf<String, PlayerData>() }
val Player.data
    get() = playerData.getOrPut(uuid()) { PlayerData() }
        .also { it.player = this }

data class UnitData(
    var init: Boolean = false,
    var tp: Boolean = false
)

open class Magic(
    val name: String,
    val tag: Set<String>,
    val icon: String,

    var cooldown: Int = 0,
    var manaCost: Int = 0,
    var chargeTime: Int = 0,
    var effect: (Player.() -> Unit)? = null,
)

class MagicCore(
    val name: String,
    val tag: Set<String>,
    val icon: String,
    val size: Int = 1,
    val magicList: MutableList<Magic> = mutableListOf<Magic>(),
    val randSeed: Int = Random.nextInt(),
    val levelNeed: Int = -1
) {
    fun chargeTime(): Int {
        return magicList.sumOf { it.chargeTime }
    }

    fun cooldown(): Int {
        return magicList.sumOf { it.cooldown }
    }

    fun manaCost(): Int {
        return magicList.sumOf { it.manaCost }
    }
}

class BlastMagic(
    val MagicName: String,
    val color: String,

    val damage: Float,
    val radius: Float,

    val range: Float,
    val speed: Float,

    val status: Set<Pair<StatusEffect, Float>>? = null,

    extraTag: List<String>? = null
): Magic("[${color}]爆炸魔法-$MagicName", buildSet {
    add("爆炸")
    extraTag?.forEach {
        add(it)
    }
}, "[${color}]☀", effect = fun Player.() {
    val realLength = range.coerceAtMost(unit().dst(mouseX ,mouseY()))
    val vec = Vec2(unit().x, unit().y).setAngle(unit().rotation).setLength(realLength)
    launch(Dispatchers.game) {
        val targetX = unit().x + vec.x
        val targetY = unit().y + vec.y
        val startX = unit().x
        var x = startX
        val startY = unit().y
        var y = startY
        var progress = 0f
        var realSpeed = speed
        realSpeed *= range / realLength
        while (true) {
            realSpeed = realSpeed.coerceAtMost(1f - progress)
            progress += realSpeed
            val tx = (targetX - startX) / (1 / realSpeed)
            val ty = (targetY - startY) / (1 / realSpeed)
            x += tx
            y += ty
            repeat(5) {
                Call.effect(Fx.fire, x + tx * (1 + it) / -5f, y + ty * (1 + it) / -5f, 0f, Color.red)
            }
            if (progress >= 1f) {
                break
            }
            Call.effect(Fx.breakBlock, targetX, targetY, radius / 8f / 2f, Color.red)
            delay(500L)
        }
        Call.logicExplosion(team(), targetX, targetY, radius, damage, true, true, false)
        status?.forEach {
            Damage.status(team(), targetX, targetY, radius, it.first, it.second, true, true)
        }
    }
})

class SpecialMagic(
    MagicName: String,
    color: String,
    radius: Float,
    val range: Float,
    speed: Float,
    specialEffect: (mindustry.gen.Unit.() -> Unit),
    extraTag: Set<String>
): Magic("[${color}]特效魔法-$MagicName", extraTag, "[${color}]＊", effect = fun Player.() {
    val realLength = range.coerceAtMost(unit().dst(mouseX ,mouseY()))
    val vec = Vec2(unit().x, unit().y).setAngle(unit().rotation).setLength(realLength)
    launch(Dispatchers.game) {
        val targetX = unit().x + vec.x
        val targetY = unit().y + vec.y
        val startX = unit().x
        var x = startX
        val startY = unit().y
        var y = startY
        var progress = 0f
        var realSpeed = speed
        realSpeed *= range / realLength
        while (true) {
            realSpeed = realSpeed.coerceAtMost(1f - progress)
            progress += realSpeed
            val tx = (targetX - startX) / (1 / realSpeed)
            val ty = (targetY - startY) / (1 / realSpeed)
            x += tx
            y += ty
            repeat(5) {
                Call.effect(Fx.overdriven, x + tx * (1 + it) / -5f, y + ty * (1 + it) / -5f, 0f, Colors.getColors().values().toList().random())
            }
            if (progress >= 1f) {
                break
            }
            Call.effect(Fx.breakBlock, targetX, targetY, radius / 8f / 2f, Color.red)
            delay(500L)
        }
        Units.nearby(null, targetX, targetY, radius) {
            specialEffect.invoke(it)
        }
    }
})

class BlinkMagic(
    val MagicName: String,
    val color: String,

    val length: Float,

    extraTag: List<String>? = null
): Magic("[${color}]位移魔法-$MagicName", buildSet {
    add("位移")
    extraTag?.forEach {
        add(it)
    }
}, "[${color}]☄", effect = fun Player.() {
    val realLength = length.coerceAtMost(unit().dst(mouseX ,mouseY()))
    val vec = Vec2(unit().x, unit().y).setAngle(unit().rotation).setLength(realLength)
    Call.effect(Fx.teleportActivate, unit().x, unit().y, 0f, Color.red)
    val x = unit().x + vec.x
    val y = unit().y + vec.y
    unit().set(x, y)
    unit().snapInterpolation()
    Call.effect(Fx.teleportOut, unit().x, unit().y, 0f, Color.red)
})

class MagicCores(
    private val blast: MagicCore = MagicCore("[scarlet]爆裂魔力核心", setOf("爆炸"), "[scarlet]☸"),
    private val blink: MagicCore = MagicCore("[sky]位移魔力核心", setOf("位移"), "[sky]☸"),
    private val fire: MagicCore = MagicCore("[red]红莲魔力核心", setOf("爆炸", "烈焰"), "[red]☸", levelNeed = 2),
    private val shield: MagicCore = MagicCore("[tan]魔盾魔力核心", setOf("护盾"), "[tan]☸"),
    private val heal: MagicCore = MagicCore("[pink]治愈魔力核心", setOf("回复"), "[pink]☸"),
    private val effect: MagicCore = MagicCore("[cyan]特效魔力核心", setOf("护盾", "回复"), "[cyan]☸", levelNeed = 2, size = 2),
    private val assist: MagicCore = MagicCore("[purple]辅战魔力核心", setOf("护盾", "辅助"), "[purple]☸", levelNeed = 2),
    private val blinkLarge: MagicCore = MagicCore("[sky]扩容位移魔力核心", setOf("位移"), "[sky]☸☸\n☸☸", levelNeed = 3, size = 2),
) {
    fun toList(): List<MagicCore> {
        return listOf(
            blast,
            blink,
            fire,
            shield,
            heal,
            effect,
            assist,
            blinkLarge
        )
    }
}

class Magics(
    val nothing: Magic = Magic("无效", setOf("debug"), " ").apply {
        cooldown = 100
        chargeTime = 100
        manaCost = 1
    },
    val empty: Magic = Magic("空", setOf("debug"), "◈").apply {
        cooldown = 100
        chargeTime = 100
        manaCost = 1
    },
    private val bomb: BlastMagic = BlastMagic("魔力炸弹", "salmon", 25f, 3f * 8f, 18 * 8f, 0.75f).apply {
        cooldown = 1_000
        chargeTime = 1_000
        manaCost = 10
    },
    private val blastLine: BlastMagic = BlastMagic("爆破射线", "scarlet", 40f, 4f * 8f, 36 * 8f, 0.3f).apply {
        cooldown = 3_000
        chargeTime = 1_500
        manaCost = 15
    },
    private val burning: BlastMagic = BlastMagic("灼焰", "red", 10f, 6f * 8f, 28 * 8f, 0.2f, setOf(Pair(StatusEffects.burning, 3 * 60f)), listOf("烈焰")).apply {
        cooldown = 3_000
        chargeTime = 2_500
        manaCost = 20
    },
    private val melting: BlastMagic = BlastMagic("烈阳", "crimson", 10f, 8f * 8f, 24 * 8f, 0.1f, setOf(Pair(StatusEffects.melting, 3 * 60f)), listOf("烈焰")).apply {
        cooldown = 5_000
        chargeTime = 3_000
        manaCost = 30
    },
    private val blink: BlinkMagic = BlinkMagic("短距闪现", "teal", 16f * 8f).apply {
        cooldown = 1_500
        chargeTime = 2_500
        manaCost = 15
    },
    private val blinkLong: BlinkMagic = BlinkMagic("障碍飞跃", "sky", 32f * 8f).apply {
        cooldown = 3_000
        chargeTime = 5_000
        manaCost = 20
    },
    private val blinkLongLong: BlinkMagic = BlinkMagic("跃迁", "white", 128f * 8f, listOf("超位")).apply {
        cooldown = 15_000
        chargeTime = 30_000
        manaCost = 150
    },
    private val heal: SpecialMagic = SpecialMagic("痊愈", "forest", 2f * 8f, 8f * 8f, 0.4f, fun mindustry.gen.Unit.() {
        heal(10f)
    }, setOf("回复")).apply {
        cooldown = 3_000
        chargeTime = 5_000
        manaCost = 10
    },
    private val shield: SpecialMagic = SpecialMagic("魔力护盾", "acid", 2f * 8f, 8f * 8f, 0.4f, fun mindustry.gen.Unit.() {
        shield(30f)
    }, setOf("护盾")).apply {
        cooldown = 2_000
        chargeTime = 4_000
        manaCost = 10
    },
    private val speed: SpecialMagic = SpecialMagic("魔力加速", "olive", 2f * 8f, 8f * 8f, 0.4f, fun mindustry.gen.Unit.() {
        apply(StatusEffects.overclock, 30f * 60f)
    }, setOf("辅助")).apply {
        cooldown = 5_000
        chargeTime = 5_000
        manaCost = 20
    },
    private val powUP: SpecialMagic = SpecialMagic("魔力透支", "gold", 2f * 8f, 8f * 8f, 0.4f, fun mindustry.gen.Unit.() {
        apply(StatusEffects.shielded, 30f * 60f)
    }, setOf("辅助")).apply {
        cooldown = 5_000
        chargeTime = 5_000
        manaCost = 20
    },
) {
    fun toList(): List<Magic> {
        return listOf(
            bomb,
            blastLine,
            burning,
            melting,
            blink,
            blinkLong,
            heal,
            shield,
            speed,
            powUP,
        )
    }
}

val Magics get() = Magics()

val unitData by autoInit { mutableMapOf<mindustry.gen.Unit, UnitData>() }
val mindustry.gen.Unit.data get() = unitData.getOrPut(this) { UnitData() }

data class TeamData(
    var score: Int = 0,
    var flagOn: mindustry.gen.Unit? = null
) {
    lateinit var team: Team

    fun pads(): List<Building> {
        return Groups.build.toList().filter { it.block is PayloadMassDriver && it.team == team }
    }
}
val teamData by autoInit { mutableMapOf<Team, TeamData>() }
val Team.data
    get() = teamData.getOrPut(this) { TeamData() }
        .also { it.team = this }

suspend fun Player.skillPointMenu() {
    menu.sendMenuBuilder<Unit>(
        this, 30_000, "[green]技能点分配",
        """
                [yellow]分配你剩余的技能点！
                [cyan]你拥有 ${data.skillPoint} 点技能点
                [lightgray]部分技能需要重生后生效
            """.trimIndent()
    ) {
        if (data.skillPoint <= 0) {
            add(listOf("[red]技能点不足" to {}))
        } else {
            add(listOf("体质(1技能点, 最多5级) - 增加血量上限，每一级获得5额外血量\n${data.skillData.con.buildLineBar(5, 5)}" to {
                if (data.skillPoint > 0 && data.skillData.con < 5) {
                    data.skillPoint--
                    data.skillData.con++
                    skillPointMenu()
                }
            }))
            add(listOf("敏捷(1技能点, 最多5级) - 加快魔法冷却，每一级减少5%\n${data.skillData.dex.buildLineBar(5, 5)}" to {
                if (data.skillPoint > 0 && data.skillData.dex < 5) {
                    data.skillPoint--
                    data.skillData.dex++
                    skillPointMenu()
                }
            }))
            add(listOf("智力(1技能点, 最多5级) - 减少魔法吟唱所需时间，每一级减少5%\n${data.skillData.int.buildLineBar(5, 5)}" to {
                if (data.skillPoint > 0 && data.skillData.int < 5) {
                    data.skillPoint--
                    data.skillData.int++
                    skillPointMenu()
                }
            }))
            add(listOf("意志(1技能点, 最多5级) - 不受debuff的透支魔力，每一级额外透支10%\n${data.skillData.pow.buildLineBar(5, 5)}" to {
                if (data.skillPoint > 0 && data.skillData.pow < 5) {
                    data.skillPoint--
                    data.skillData.pow++
                    skillPointMenu()
                }
            }))

            add(listOf("魔力亲和(2技能点) - 多回复1点魔力,上限加20\n${if (data.skillData.affinity) "[green]激活" else "[red]未激活"}" to {
                if (data.skillPoint > 0 && !data.skillData.affinity) {
                    data.skillPoint -= 2
                    data.skillData.affinity = true
                    skillPointMenu()
                }
            }))
            add(listOf("魔力等级(5技能点, 最多5级) - 可使用更加强大的魔法核心\n${data.level.buildLineBar(5, 5)}" to {
                if (data.skillPoint > 0 && data.level < 5) {
                    data.skillPoint -= 5
                    data.level++
                    skillPointMenu()
                }
            }))
        }
        add(listOf("退出" to {}))
    }
}

suspend fun Player.magicCoreChooseMenu(core: MagicCore? = null): MagicCore? {
    var target: MagicCore? = null
    menu.sendMenuBuilder<Unit>(
        this, 120_000, "[green]选择魔法核心",
        """
                [yellow]这将决定你可以配置什么魔法
            """.trimIndent()
    ) {
        MagicCores().toList().filter { it.levelNeed <= data.level }.sortedBy { it.levelNeed }.forEach {
            add(listOf("${if (core?.name == it.name) "[green]" else "[white]"}${it.name}\n[white]${it.tag.joinToString(" ")}" to {
                target = it
            }))
        }
    }
    return target
}

suspend fun Player.magicChooseMenu(core: MagicCore, magic: Magic? = null): Magic? {
    var target: Magic? = null
    menu.sendMenuBuilder<Unit>(
        this, 120_000, "[green]选择魔法",
        """
                [yellow]这将决定你的魔法效果
            """.trimIndent()
    ) {
        Magics.toList().filter { !it.tag.any { it !in core.tag } }.forEach {
            add(listOf("${if (magic?.name == it.name) "[green]" else "[white]"}${it.name}\n[white]${it.tag.joinToString(" ")}" to {
                target = it
            }))
        }
    }
    return target
}

suspend fun Player.magicCoreMenu(index: Int = 0) {
    menu.sendMenuBuilder<Unit>(
        this, 120_000, "[green]魔法核心配置",
        """
                [yellow]创造你自己的魔法！
            """.trimIndent()
    ) {
        if (data.magicCores.isEmpty())
            add(listOf("[red]你没有魔法核心！" to { magicCoreMenu(index) }))
        else {
            val magicCore = data.magicCores[(if (index + 1 <= data.magicCores.size) index else 0 )]
            val magics = magicCore.magicList
            val usedNum = mutableSetOf<Int>()
            val magicMap = buildMap {
                magics.forEach {
                    var times = 0
                    var num = Random(magicCore.randSeed).nextInt(0, 23)
                    while (times++ <= 40) {
                        if (num in usedNum || num == 13)
                            num = Random(magicCore.randSeed + times).nextInt(0, 23)
                        else
                            break
                    }
                    put(num, it)
                    usedNum.add(num)
                }
            }
            repeat(5) { i ->
                add(buildList{
                    repeat(5) { j ->
                        if (i == 2 && j == 2)
                            add(magicCore.icon to {
                                val newCore = magicCoreChooseMenu(magicCore)
                                if (newCore != null){
                                    data.magicCores.remove(magicCore)
                                    data.magicCores.add(newCore)
                                    repeat(newCore.size) { newCore.magicList.add(Magics.empty) }
                                    magicCoreMenu(data.magicCores.size - 1)
                                }
                            })
                        else {
                            val magic = magicMap.getOrDefault(i * 5 + j + 1, Magics.nothing)
                            add(magic.icon to {
                                if (magic.name != Magics.nothing.name) {
                                    val newMagic = magicChooseMenu(magicCore, magic)
                                    if (newMagic != null) {
                                        magics[magics.indexOf(magic)] = newMagic
                                    }
                                }
                                magicCoreMenu(index)
                            })
                        }
                    }
                })
            }
        }


        if (data.magicCores.size >= 2)
            add(buildList { repeat(data.magicCores.size) {
                add("${if (it == index) "[green]" else "[white]"}#${it}" to {
                    magicCoreMenu(it)
                })
            }})
        if (data.magicCores.size < 3)
            add(listOf("[cyan]创建一个魔法核心" to {
                val newCore = magicCoreChooseMenu()
                if (newCore != null){
                    repeat(newCore.size) { newCore.magicList.add(Magics.empty) }
                    data.magicCores.add(newCore)
                    magicCoreMenu(index)
                }
            }))
        else
            add(listOf("[red]无法创建更多的魔法核心了！" to { magicCoreMenu(index) }))
        add(listOf("退出" to { }))
    }
}



onEnable {
    contextScript<coreMindustry.ContentsTweaker>().addPatch("TW",contentPatch)
    launch(Dispatchers.game) {
        delay(5_000)
        Groups.player.filter { it.data.skillPoint > 0 }.forEach {
            launch(Dispatchers.game) {
                it.skillPointMenu()
            }
        }
    }
    if (mode == "夺旗") {
        loop(Dispatchers.game) {
            Vars.state.teams.getActive().forEach { t ->
                val pads = t.team.data.pads()
                val accelerators = Groups.build.toList().filter { it.block is Accelerator && it.team == t.team }
                accelerators.forEach {
                    Call.label(buildString {
                        appendLine("[#${it.team.color}]${it.team.localized()} 旗帜")
                        if (it.team.data.flagOn == null) {
                            appendLine("[green]存放中！")
                        } else {
                            appendLine("[red]被夺取")
                            appendLine("[cyan]<ARC端>点击获取旗帜位置标记")
                        }
                        append("[#${it.team.color}]${it.team.data.score}/5")
                    }, 1.013f, it.x, it.y)
                }
                pads.forEach padsForEach@{
                    Groups.player.forEach { p ->
                        Call.label(p.con, buildString {
                            appendLine("[#${it.team.color}]${it.team.localized()} 传送台")
                            appendLine("[cyan]靠近点击即可传送！(10s)")
                            if (p.within(it, Vars.itemTransferRange / 2f) && p.team() == t.team) {
                                append("[green]点击传送！")
                            } else {
                                append("[lightgray]未满足使用条件")
                            }
                        }, 1.013f, it.x, it.y)
                    }
                }
                if (t.team.data.flagOn?.dead == true || t.team.data.flagOn?.isValid == false) {
                    broadcast("[#{teamColor}]{team} 的旗帜已经被放回！".with("teamColor" to t.team.color,
                        "team" to t.team.localized()))
                    t.team.data.flagOn = null
                }
                if (t.team.data.score >= 5 && !Vars.state.gameOver) {
                    Events.fire(EventType.GameOverEvent(t.team))
                    Vars.state.gameOver = true
                }
            }
            delay(1000)
        }
    }
    loop(Dispatchers.game) {
        Groups.unit.forEach {
            it.apply(StatusEffects.disarmed, 9999999f)
            if (it.isPlayer && !it.data.init) {
                it.maxHealth += it.player.data.skillData.con * 5f
                it.health = it.maxHealth
                it.data.init = true
                it.player.data.mana = it.player.data.manaMax
            }
        }
        Groups.player.filter { !it.dead() }.forEach {
            val maxRange = it.data.maxRange()
            if (it.unit().isShooting && it.data.cooldown < Time.millis()) {
                if (it.data.shootingStartTime == 0L)
                    it.data.shootingStartTime = Time.millis()
            } else {
                if (it.data.shootingStartTime != 0L) {
                    if (it.data.magicCore != null) {
                        if (Time.millis() - it.data.shootingStartTime > it.data.chargeTime()) {
                            launch(Dispatchers.game) {
                                it.data.magicCore!!.magicList.forEach { m ->
                                    m.effect?.invoke(it)
                                    delay(500L)
                                }
                            }
                            it.data.cooldown = Time.millis() + it.data.cooldown()
                            it.data.mana -= it.data.manaCost()
                        }
                    }
                }
                it.data.shootingStartTime = 0L
            }
            if (!it.within(it.mouseX, it.mouseY, (if (maxRange <= 0) Vars.itemTransferRange else maxRange) * 2.5f)) {
                it.data.shootingStartTime = 0L
            }
            if (!it.unit().hasItem() && !it.dead()) {
                it.unit().addItem(Items.dormantCyst)
                if (it.data.magicCores.isNotEmpty()) {
                    if (it.data.magicCore == null)
                        it.data.magicCore = it.data.magicCores[0]
                    else {
                        if (it.data.magicCores.indexOf(it.data.magicCore) + 1 == it.data.magicCores.size)
                            it.data.magicCore = it.data.magicCores[0]
                        else
                            it.data.magicCore = it.data.magicCores[it.data.magicCores.indexOf(it.data.magicCore) + 1]
                        //it.data.magicCore = it.data.magicCores[it.data.magicCores.indexOf(it.data.magicCore) + 1 % it.data.magicCores.size]
                    }
                    it.sendMessage("[green]魔法切换！")
                }
            }
        }
        yield()
    }
    loop(Dispatchers.game) {
        Groups.player.forEach {
            Call.setHudText(it.con, buildString {
                appendLine("[crimson]生命值[white]：${it.unit().health.format(1)}/${it.unit().maxHealth} ${it.unit().health.buildLineBar(10, it.unit().type.health ,Pair(Pair("[yellow]", "[green]"), "[red]"))}")
                appendLine("[cyan]魔力值[white]：${it.data.mana.format(1)}% ${it.data.mana.buildLineBar(10, 100f ,Pair(Pair("[blue]", "[sky]"), "[red]"))}")
                if (it.data.magicCore == null && it.data.magicCores.isEmpty())
                    appendLine("[red]你没有配置魔法!输入/m或/magic来配置魔法")
                else if (it.data.magicCore == null)
                    appendLine("[red]未切换至有效魔法\n丢弃单位身上物品以切换")
                else {
                    appendLine("[green]${it.data.magicCore?.name} 使用中")
                    if (it.data.magicCores.size >= 2)
                        appendLine("[lightgray]你拥有2个及以上的魔法核心,丢弃单位身上物品以切换")
                    if (Time.millis() >= it.data.cooldown)
                        appendLine("[green]魔法冷却完毕!长按地面释放")
                    else
                        appendLine("[red]魔法冷却中.. ${((it.data.cooldown - Time.millis()) / 1000f).format(1)}s")
                }
                if (it.data.skillPoint > 0) {
                    appendLine("[cyan]你有未分配的技能点！输入/s或/sp以分配")
                }
            })
        }
        delay(500)
    }
    loop(Dispatchers.game) {
        Groups.player.forEach {
            it.data.mana += 2.5f + if (it.data.skillData.affinity) 1f else 0f
            if (it.data.mana >= it.data.manaMax) {
                it.data.mana = it.data.manaMax
                it.unit().heal(it.unit().maxHealth * 0.05f)
            }
            if (it.unit().shield > 0) {
                it.unit().shield -= (it.unit().shield / 10f).coerceAtLeast(2.5f)
            }
        }
        delay(3_000)
    }

    loop(Dispatchers.game) {
        Groups.player.forEach {
            if (it.dead()) return@forEach
            if (it.data.cooldown < Time.millis()) {
                val blinkMagics = buildList {
                    it.data.magicCore?.magicList?.forEach {
                        if (it is BlinkMagic) add(it)
                    }
                }
                if (blinkMagics.isNotEmpty()) {
                    var totalLength = 0f
                    blinkMagics.forEach { m ->
                        val length = (m.length + totalLength).coerceAtMost(it.unit().dst(it.mouseX, it.mouseY()))
                        totalLength = length
                        val vec = Vec2(it.unit().x, it.unit().y).setAngle(it.unit().rotation).setLength(length)
                        Call.effect(it.con, Fx.regenParticle, it.unit().x + vec.x, it.unit().y + vec.y, 1f, Color.red)
                    }
                }
                val blastMagics = buildList {
                    it.data.magicCore?.magicList?.forEach {
                        if (it is BlastMagic) add(it)
                    }
                }
                blastMagics.forEach { m ->
                    val realLength = m.range.coerceAtMost(it.unit().dst(it.mouseX, it.mouseY()))
                    val vec = Vec2(it.unit().x, it.unit().y).setAngle(it.unit().rotation).setLength(realLength)
                    Call.effect(it.con, Fx.fire, it.unit().x + vec.x, it.unit().y + vec.y, 1f, Color.red)
                }
                val specialMagics = buildList {
                    it.data.magicCore?.magicList?.forEach {
                        if (it is SpecialMagic) add(it)
                    }
                }
                specialMagics.forEach { m ->
                    val realLength = m.range.coerceAtMost(it.unit().dst(it.mouseX, it.mouseY()))
                    val vec = Vec2(it.unit().x, it.unit().y).setAngle(it.unit().rotation).setLength(realLength)
                    Call.effect(it.con, Fx.overdriven, it.unit().x + vec.x, it.unit().y + vec.y, 1f, Colors.getColors().values().toList().random())
                }
            }
            if (it.data.shootingStartTime != 0L && it.data.magicCore != null) {
                Call.effect(it.con, Fx.shieldBreak, it.unit().x, it.unit().y, 100f * it.data.chargeTime() / (Time.millis() - it.data.shootingStartTime), Color.red)
                if (Time.millis() - it.data.shootingStartTime > it.data.chargeTime())
                    Call.effect(it.con, Fx.shieldWave, it.unit().x, it.unit().y, 0f, Color.red)
            }
        }
        delay(150)
    }

}

listen<EventType.PlayerJoin> {
    if (it.player.data.skillPoint > 0) {
        launch(Dispatchers.game) { it.player.skillPointMenu() }
    }
}

command("magic", "配置魔法") {
    type = CommandType.Client
    aliases = listOf("m")
    body {
        launch(Dispatchers.game) {
            player!!.magicCoreMenu()
        }
    }
}

command("skillPoint", "技能点分配") {
    type = CommandType.Client
    aliases = listOf("s", "sp")
    body {
        launch(Dispatchers.game) {
            player!!.skillPointMenu()
        }
    }
}

suspend fun Player.launchPadMenu(pad: PayloadDriverBuild) {
    val pads = team().data.pads()
    menu.sendMenuBuilder<Unit>(
        this, 600_000, "[green]传送台\n[cyan]传送台总数[yellow]${pads.size}",
        """
            [cyan]花费10s传送至目标发射台
        """.trimIndent()
    ) {
        if (pads.size >= 2) {
            pads.filter { it != pad }.forEach {
                add(listOf("${Iconc.blockLargePayloadMassDriver}(${it.tileX()},${it.tileY()})${Iconc.blockLargePayloadMassDriver}" to {
                    if (!unit().data.tp && within(pad, Vars.itemTransferRange / 2f)) {
                        unit().data.tp = true
                        unit().apply(StatusEffects.unmoving, 10 * 60f)
                        delay(10_000)
                        unit().data.tp = false
                        unit().set(it)
                        unit().snapInterpolation()
                    }
                }))
            }
        } else {
            add(listOf("[lightgray]队伍发射台数量不足！" to { launchPadMenu(pad) }))
        }
        this += listOf(
            "取消" to {}
        )
    }
}

listen<EventType.TapEvent> {
    val player = it.player
    if (player.dead()) return@listen
    when (mode) {
        "夺旗" -> {
            if (it.tile.block() is Accelerator) {
                if (it.tile.team().data.flagOn != null) {
                    broadcast("[#{teamColor}]<Mark>[white]({x},{y})".with("x" to it.tile.team().data.flagOn!!.x / 8,
                        "y" to it.tile.team().data.flagOn!!.y / 8,
                        "teamColor" to it.tile.team().color),
                        quite = true,
                        players = listOf(player))
                }
                if (it.tile.team() == player.team()) {
                    val flagTeams =
                        Vars.state.teams.getActive().toArray().filter { t -> t.team.data.flagOn == player.unit() }
                    if (it.tile.within(it.player, Vars.itemTransferRange / 4f)) {
                        if (it.tile.team().data.flagOn != null) {
                            player.sendMessage("[red]你队伍的旗帜处于丢失状态。")
                        } else {
                            flagTeams.forEach {
                                player.unit().apply {
                                    unapply(StatusEffects.sporeSlowed)
                                    unapply(StatusEffects.muddy)
                                }
                                player.team().data.score++
                                Call.sendMessage("${player.name} 成功放回了 [#${it.team.color}]${it.team.localized()} [white]的旗帜！\n [#${player.team().color}]${player.team().data.score}/5")
                                it.team.data.flagOn = null
                            }
                        }
                    }
                }
                if (it.tile.team() != player.team() && it.tile.team().data.flagOn == null && it.tile.within(player,
                        Vars.itemTransferRange / 4f)
                ) {
                    player.unit().apply {
                        apply(StatusEffects.sporeSlowed, 999999f)
                        apply(StatusEffects.muddy, 999999f)
                    }
                    it.tile.team().data.flagOn = player.unit()
                    broadcast("[red]你队伍的旗帜被\n[white]{player}\n[red]夺取！".with("player" to player.name),
                        MsgType.WarningToast,
                        players = Groups.player.filter { p -> p.team() == it.tile.team() },
                        quite = true)
                    broadcast("[#{teamColor}]{team} 的旗帜被 [white]{player} [#{teamColor}]夺取！".with("player" to player.name,
                        "teamColor" to it.tile.team().color,
                        "team" to it.tile.team().localized()),
                        quite = true)
                    broadcast("[#eab678ff]<Mark>[white]({x},{y})".with("x" to player.x / 8, "y" to player.y / 8), quite = true)
                }
            }
            if (it.tile.block() is PayloadMassDriver) {
                if (it.tile.within(it.player, Vars.itemTransferRange / 2f)) {
                    launch(Dispatchers.game) {
                        it.player.launchPadMenu(it.tile.build as PayloadDriverBuild)
                    }
                }
            }
        }
    }
}
//TODO 更多魔法