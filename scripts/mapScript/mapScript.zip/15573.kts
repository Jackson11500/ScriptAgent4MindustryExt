@file:Depends("coreMindustry/utilNext", "调用菜单")
@file:Depends("coreMindustry/contentsTweaker", "修改单位属性")

package mapScript

import arc.math.Mathf
import arc.math.geom.Vec2
import coreMindustry.lib.game
import mindustry.Vars
import mindustry.ai.types.GroundAI
import mindustry.content.UnitTypes
import mindustry.game.Team
import mindustry.gen.Call
import mindustry.gen.Player
import org.intellij.lang.annotations.Language
import kotlin.math.abs
import kotlin.random.Random

/**@author xkldklp
 * https://mdt.wayzer.top/v2/map/15573/latest
 */
name = "Mindustry's BattleGround"

val menu = contextScript<coreMindustry.UtilNext>()

fun Float.format(i: Int = 2): String {
    return "%.${i}f".format(this)
}

fun Float.buildLineBar(length: Int = 20, max: Float = 20f, color: Pair<Pair<String, String>, String> = Pair(Pair("[yellow]","[green]"), "[red]")): String {
    val num = this
    return buildString {
        repeat(length) {
            append("${
                when {
                    num > it * (max / length) + max -> color.first.first
                    num > it * (max / length) -> color.first.second
                    else -> color.second
                }
            }|")
        }
    }
}

fun Int.buildLineBar(length: Int = 20, max: Int = 20, color: Pair<Pair<String, String>, String> = Pair(Pair("[yellow]","[green]"), "[red]")): String {
    return toFloat().buildLineBar(length, max.toFloat(), color)
}

val contentPatch
    @Language("JSON5")
    get() = """
{
  "unit": {
    "oct": {
      "fogRadius": 999,
    },
    "flare": {
      "health": 10,
    }
  },
}"""

/**
 *  0 -> 从下往上
 *  1 -> 从右往左
 *  2 -> 从上往下
 *  3 -> 从左往右
 */
val direction by autoInit { Random.nextInt(0, 3) }

class PlaneAI : GroundAI() {
    override fun updateUnit() {
        if (unit.team == Team.sharded) {
            val targetX = when (direction) {
                0 -> Random(unit.id).nextInt(0, Vars.world.width())
                1 -> 0
                2 -> Random(unit.id).nextInt(0, Vars.world.width())
                3 -> Vars.world.width()
                else -> 0
            }
            val targetY = when (direction) {
                0 -> Vars.world.height()
                1 -> Random(unit.id).nextInt(0, Vars.world.height())
                2 -> 0
                3 -> Random(unit.id).nextInt(0, Vars.world.height())
                else -> 0
            }
            unit.moveAt(Vec2().trns(Mathf.angle(unit.x - targetX * 8, unit.y - targetY * 8), unit.speed() * 0.75f))
            if (abs(unit.x - targetX * 8) <= 10 * 8 && abs(unit.y - targetY * 8) <= 10 * 8) {
                unit.kill()
            }
            if (unit.moving()) unit.lookAt(unit.vel().angle())
        }
    }
}

val survivalPlayers by autoInit { mutableSetOf<Player>() }

onEnable {
    contextScript<coreMindustry.ContentsTweaker>().addPatch("MDBG",contentPatch)
    Vars.state.rules.apply {
        possessionAllowed = false
        canGameOver = false
        unitCap = 999
        cleanupDeadTeams = false
    }
    Call.setRules(Vars.state.rules)
    Team.sharded.cores().forEach {
        it.kill()
    }
    launch(Dispatchers.game) {
        val spawnX = when (direction) {
            0 -> Random.nextInt(0, Vars.world.width())
            1 -> Vars.world.width()
            2 -> Random.nextInt(0, Vars.world.width())
            3 -> 0
            else -> 0
        }
        val spawnY = when (direction) {
            0 -> 0
            1 -> Random.nextInt(0, Vars.world.height())
            2 -> Vars.world.height()
            3 -> Random.nextInt(0, Vars.world.height())
            else -> 0
        }
        UnitTypes.oct.spawn(Team.sharded, spawnX * 8f, spawnY * 8f).apply {
            Call.setCameraPosition(x, y)
            controller(PlaneAI())
        }
    }
}