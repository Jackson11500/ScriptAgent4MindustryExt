@file:Depends("coreMindustry/utilNext", "调用菜单")
@file:Depends("coreMindustry/contentsTweaker", "修改核心单位,单位属性")
@file:Depends("coreMindustry/utilMapRule", "修改单位ai")
@file:Depends("wayzer/maps", "获取地图信息")
@file:Depends("wayzer/user/achievement", "成就")

package mapScript

import arc.Events
import arc.func.Prov
import arc.math.Mathf
import arc.math.Mathf.ceil
import arc.math.Mathf.floor
import arc.math.geom.Vec2
import arc.util.Time
import coreLibrary.lib.config
import coreLibrary.lib.util.loop
import coreLibrary.lib.with
import coreMindustry.lib.*
import mindustry.Vars.*
import mindustry.ai.types.FlyingAI
import mindustry.ai.types.GroundAI
import mindustry.content.Blocks
import mindustry.content.StatusEffects
import mindustry.content.UnitTypes
import mindustry.entities.Predict
import mindustry.entities.Units
import mindustry.entities.abilities.UnitSpawnAbility
import mindustry.entities.units.UnitController
import mindustry.game.EventType
import mindustry.game.Team
import mindustry.gen.*
import mindustry.gen.Unit
import mindustry.type.UnitType
import mindustry.world.Block
import mindustry.world.blocks.distribution.Conveyor
import mindustry.world.blocks.liquid.Conduit
import mindustry.world.blocks.payloads.BuildPayload
import org.intellij.lang.annotations.Language
import wayzer.MapManager
import wayzer.lib.dao.PlayerData
import kotlin.math.pow
import kotlin.random.Random


/**@author xkldklp
 * https://mdt.wayzer.top/v2/map/15006/latest
 */
name = "终末之时"
//The End RRRRRemake

val menu = contextScript<coreMindustry.UtilNext>()
val achievement = contextScript<wayzer.user.Achievement>()

val amount by config.key(200, "通关经验奖励")

val waveDelay by lazy { state.rules.waveSpacing / 60 * 1000 }
val worldWidth by lazy { world.unitWidth().toFloat() }
val worldHeight by lazy { world.unitHeight().toFloat() }
val worldCenterX by lazy { worldWidth / 2f }
val worldCenterY by lazy { worldHeight / 2f }

val stage get() = ceil( waves / 10f)
val stageName get() = when(stage) {
    0 -> "[white]天灾未临"
    1 -> "[white]天灾未临"
    2 -> "[purple]天灾降临"
    3 -> "[purple]终之封"
    4 -> "[purple]终之扉"
    5 -> "[red]终之时"
    6 -> "[red]终末之时"
    else -> ""
}
//5stage

val startTime = Time.millis()
var waveStartTime = Time.millis()

var waves = 0
//50waves 10waves/stage

val waveOver get() = state.rules.waveTeam.data().unitCount <= 0

val unitCosts = mapOf(
    UnitTypes.nova to 75,
    UnitTypes.pulsar to 150,
    UnitTypes.quasar to 1000,
    UnitTypes.vela to 7500,
    UnitTypes.corvus to 250000,

    UnitTypes.dagger to 10,
    UnitTypes.mace to 100,
    UnitTypes.fortress to 750,
    UnitTypes.scepter to 10000,
    UnitTypes.reign to 250000,

    UnitTypes.crawler to 7500,//技能：技能：生成Crawler Max100 10s
    UnitTypes.atrax to 150,
    UnitTypes.spiroct to 750,
    UnitTypes.arkyid to 15000,
    UnitTypes.toxopid to 325000,

    UnitTypes.flare to 75,
    UnitTypes.horizon to 250,
    UnitTypes.zenith to 2500,
    UnitTypes.antumbra to 18000,
    UnitTypes.eclipse to 175000,

    UnitTypes.retusa to 400,
    UnitTypes.oxynoe to 850,
    UnitTypes.cyerce to 5000,
    UnitTypes.aegires to 30000,
    UnitTypes.navanax to 350000,

    UnitTypes.risso to 500,
    UnitTypes.minke to 750,
    UnitTypes.bryde to 5000,
    UnitTypes.sei to 75000,
    UnitTypes.omura to 1500000,

    UnitTypes.mono to 3750000,//技能：随机生成T5 5s
    UnitTypes.poly to 100000,//技能：生成Poly Max100 10s
    UnitTypes.mega to 2000,
    UnitTypes.quad to 20000,
    UnitTypes.oct to 250000
)
val unitCostsE = mapOf(
    UnitTypes.atrax to 12,
    UnitTypes.spiroct to 125,
    UnitTypes.arkyid to 5000,
    UnitTypes.toxopid to 25000
)
val t1blockRandom = mapOf(
    Blocks.itemSource to 3,
    Blocks.liquidSource to 2,
    Blocks.arc to 3,
    Blocks.lancer to 1,
    Blocks.scorch to 2,
    Blocks.hail to 2,
    Blocks.salvo to 1,
    Blocks.repairPoint to 1,
)
val t2blockRandom = mapOf(
    Blocks.swarmer to 4,
    Blocks.cyclone to 6,
    Blocks.tsunami to 2,
    Blocks.spectre to 4,
    Blocks.meltdown to 4,
    Blocks.foreshadow to 2,
    Blocks.repairTurret to 4,
    Blocks.unitRepairTower to 2,
    Blocks.overdriveProjector to 1,
)
val t3blockRandom = mapOf(
    Blocks.malign to 5,
    Blocks.smite to 4,
    Blocks.scathe to 3
)
val contentPatch
    @Language("JSON5")
    get() = """
{
  "block": {
    "item-source.health": 1000,
    "liquid-source.health": 1000,
  },
  "unit": {
    "retusa.flying": true,
    "oxynoe.flying": true,
    "cyerce.flying": true,
    "aegires.flying": true,
    "navanax.flying": true,
    "risso.flying": true,
    "minke.flying": true,
    "bryde.flying": true,
    "sei.flying": true,
    "omura.flying": true,
    "omura": {
      "health": 80000,
      "weapons.0.bullet.damage": 62500,
      "weapons.0.reload": 550,
      "weapons.0.cooldownTime": 450,
      "weapons.0.bullet.length": 1500,
      "weapons.0.bullet.pierceDamageFactor": 1,
      "weapons.0.bullet.pointEffectSpace": 10,
      "weapons.0.recoil": 25,
    },
    "atrax.maxRange": 4000,
    "spiroct":{
      "maxRange": 4000,
      "weapons.2.bullet.sapStrength": 0,
      "weapons.0.bullet.sapStrength": 0
    },
    "arkyid":{
      "maxRange": 4000,
      "weapons.0.bullet.sapStrength": 0
    },
    "toxopid.maxRange": 4000,
    "reign.maxRange": 4000,
    "poly":{
      "maxRange": 4000,
      "health": 75,
      "speed": 1.5,
      "abilities.+=": [{
          "type": "UnitSpawnAbility",
          "spawnTime": 1280,
          "unit": "poly",
          "spawnX": 0,
          "spawnY": -8
        }
      ],
    }, 
    "crawler":{
      "abilities.+=": [{
          "type": "UnitSpawnAbility",
          "spawnTime": 1280,
          "unit": "crawler",
          "spawnX": 0,
          "spawnY": -8
        }
      ],
    }, 
    "mono": {
      "health": 100000,
      "abilities.+=": [
        {
          "type": "ForceFieldAbility",
          "radius": 200,
          "regen": 9,
          "max": 99999,
          "cooldown": 99
        }
      ],
    },
    "reign.speed": 1.5,
  },
}"""
fun Player.createUnit(unitType: UnitType, despawn: Boolean = false): Unit{
    val sx: Float
    val sy: Float
    if (unit().maxHealth <= 1) {
        sx = worldCenterX
        sy = worldCenterY
    } else {
        sx = x
        sy = y
    }
    val u = unitType.spawn(state.rules.defaultTeam, sx, sy).apply {
        if (despawn || unit().maxHealth <= 1) unit(this)
        spawnedByCore = despawn
        if (con.mobile) Call.setCameraPosition(con, sx, sy)
    }
    u.mounts.get(0).smoothReload
    if (unitType == UnitTypes.mono) {
        launch(Dispatchers.game) {
            val unit = arrayOf(UnitTypes.toxopid, UnitTypes.corvus, UnitTypes.reign).random()
            while (!u.dead) {
                delay(5000)
                if ((u.team.data().getUnits(unit)?.size ?: 0) < state.rules.unitCap)
                    unit.spawn(u.team, u.x, u.y)
            }
        }
    }
    if (unitType == UnitTypes.poly) {
        u.maxHealth = 3000f
        u.health = 3000f
        u.apply(StatusEffects.boss, 999999f)
        u.apply(StatusEffects.overclock, 999999f)
        u.apply(StatusEffects.overdrive, 999999f)
        (u.abilities[1] as UnitSpawnAbility).spawnTime = 106f
    }
    if (unitType == UnitTypes.crawler) {
        u.maxHealth = 6000f
        u.health = 6000f
        u.apply(StatusEffects.boss, 999999f)
        u.apply(StatusEffects.overclock, 999999f)
        u.apply(StatusEffects.overdrive, 999999f)
        (u.abilities[0] as UnitSpawnAbility).spawnTime = 44f
    }
    return u
}
fun createEnemy(unitType: UnitType, noCost: Boolean = false): Unit{
    val sx: Float
    val sy: Float
    when(Random.nextInt(1,4)){
        1 -> {
            //up
            sy = worldHeight - 16f
            sx = Random.nextFloat() * worldWidth
        }
        2 -> {
            //down
            sy = 16f
            sx = Random.nextFloat() * worldWidth
        }
        3 -> {
            //left
            sy = Random.nextFloat() * worldHeight
            sx = 16f
        }
        4 -> {
            //right
            sy = Random.nextFloat() * worldHeight
            sx = worldWidth - 16f
        }
        else -> {
            sx = worldCenterX
            sy = worldCenterY
        }
    }
    unitType.create(state.rules.waveTeam).apply {
        if (!noCost) enemyCoins -= unitCostsE[type] ?: 0
        set(sx, sy)
        add()
        if (waves > 10) apply(StatusEffects.overdrive)
        if (waves > 20) apply(StatusEffects.overclock, 999999f)
        if (waves > 30) apply(StatusEffects.boss)
        if (waves > 40) apply(StatusEffects.shielded, 999999f)
        return this
    }
}
fun UnitType.trySummonEnemy(): Boolean {
    if (enemyCoins >= (unitCostsE[this] ?: 0) && (state.rules.waveTeam.data().getUnits(this)?.size ?: 0) < max()) {
        createEnemy(this)
        return true
    }
    return false
}

fun Player.respawn(){
    createUnit(UnitTypes.dagger, true).shield += 1000
}

fun Float.format(i: Int = 2): String {
    return "%.${i}f".format(this)
}

var teamCoins = 0
var enemyCoins = 0
val t2Max get() = (waves + 2) * Groups.player.size().coerceAtMost(10)
val t3Max get() = floor(((waves - 1) / 3f).pow(1.4f) * (Groups.player.size() / 1.8f).coerceAtLeast(1f).coerceAtMost(3f))
val t4Max get() = floor(((waves - 3) / 5f).pow(1.8f) * (Groups.player.size() / 2f).coerceAtLeast(1f).coerceAtMost(3f))
val t5Max get() = floor(((waves - 6) / 10f).pow(2.2f) * (Groups.player.size() / 3f).coerceAtLeast(1f).coerceAtMost(3f))
fun UnitType.max(): Int{
    return when(this){
        UnitTypes.atrax -> t2Max
        UnitTypes.spiroct -> t3Max
        UnitTypes.arkyid -> t4Max
        UnitTypes.toxopid -> t5Max
        else -> 0
    }
}
class Artifact(
    val name: String,
    val desc: String,
    val level: Int,
    var effect: (Player.() -> kotlin.Unit)? = null,
    var timerEffect : (Player.() -> kotlin.Unit)? = null,
    var attackEffect: (Pair<Player,  EventType.UnitDamageEvent>.() -> kotlin.Unit)? = null,
    var defEffect: (Pair<Player,  EventType.UnitDamageEvent>.() -> kotlin.Unit)? = null,
    val only: Boolean = false
) {
    fun active(player: Player): Boolean {
        if (canActive(player)){
            player.data.artifacts.add(this)
            effect?.invoke(player)
            broadcast("{player} [yellow]获取了{name}".with("player" to { player.name }, "name" to name))
            return true
        }
        return false
    }
    fun canActive(player: Player): Boolean {
        return !(player.data.artifacts.contains(this) && only)
    }
}

enum class Artifacts(
    val regen: Artifact = Artifact("星铭-再生", "每秒恢复2%最大生命值", 1, timerEffect = fun Player.(){
        unit().health += unit().maxHealth * 0.02f
        unit().clampHealth()
    })
)

data class PlayerData(
    var coins: Int = 0,
    var gived: Boolean = false,
    val artifacts: MutableList<Artifact> = mutableListOf()
)
val playerData by lazy { mutableMapOf<String, PlayerData>() }
val Player.data
    get() = playerData.getOrPut(uuid()) { PlayerData() }

class SwarmAI : FlyingAI() {
    private var swarmRange = 320f
    private var innerSwarmRange2 = 120f * 120f
    private var avoidRange = 480f
    private var avoidRange2 = avoidRange * avoidRange
    private var kiteRange = 0.8f
    var swarmCount = 10
    override fun updateMovement() {
        if (target != null && unit.hasWeapons()) {
            if (!unit.type.circleTarget) {
                if (Units.count(unit.x, unit.y, swarmRange
                    ) { u: mindustry.gen.Unit -> u.type === unit.type && u.team === unit.team } > swarmCount
                ) {
                    moveTo(target, unit.type.range * kiteRange)
                } else if (target != null) {
                    val targetPosc: Posc = target
                    if (unit.dst2(targetPosc) > avoidRange2) {
                        val targetSameType: Unit? = Units.closest(unit.team, unit.x, unit.y
                        ) { u: mindustry.gen.Unit ->
                            u.type === unit.type && unit.dst2(u) > innerSwarmRange2
                        }
                        moveTo(targetSameType ?: target, unit.hitSize * 2f)
                    } else {
                        moveTo(target, avoidRange * 1.1f)
                    }
                } else {
                    moveTo(null, avoidRange)
                }
                unit.lookAt(target)
            } else {
                circleAttack(120f)
            }
        }
        if (target == null && state.rules.waves && unit.team === state.rules.defaultTeam) {
            moveTo(closestSpawner, state.rules.dropZoneRadius + 130f)
        }
    }
}
class ArenaAI : GroundAI() {
    override fun updateUnit() {
        if (Units.invalidateTarget(target, unit.team, unit.x, unit.y, Float.MAX_VALUE)) {
            target = null
        }
        if (retarget() || (target as? Unit)?.dead == true) {
            target = target(unit.x, unit.y, unit.range(), unit.type.targetAir, unit.type.targetGround)
        }
        var rotate = false
        var shoot = false
        if (!Units.invalidateTarget(target, unit, unit.range()) && unit.hasWeapons()) {
            rotate = true
            shoot = unit.within(target,
                unit.type.weapons.maxOf { it.range() } + if (target is Building) 1.5f * tilesize / 2f else (target as Hitboxc).hitSize() / 2f)
            if (unit.type.hasWeapons()) unit.aimLook(Predict.intercept(unit,
                target,
                unit.type.weapons.first().bullet.speed))
        }
        if (target != null) {
            unit.moveAt(vec.set(target).sub(unit).limit(unit.speed()))
            if (unit.moving()) unit.lookAt(unit.vel().angle())
            unit.controlWeapons(rotate, shoot)
        }
    }
    override fun target(x: Float, y: Float, range: Float, air: Boolean, ground: Boolean): Teamc? {
        return Units.closestTarget(unit.team, x, y, range,
            { u: Unit -> u.checkTarget(air, ground) && u.team != Team.get(42) }
        ) { t: Building? -> ground && t?.block !is Conveyor && t?.block !is Conduit }
    }
}
class ReinforcementAI : GroundAI() {
    override fun updateUnit() {
        if (unit.team === Team.get(42)) {
            unit.moveAt(Vec2().trns(Mathf.atan2(world.width() * 4 - unit.x, world.height() * 4 - unit.y), unit.speed() * 2.5f))
            if (unit.x > worldCenterX + Random(unit.id).nextInt(-160, 160)) {
                Call.payloadDropped(unit, unit.x, unit.y)
            }
            if (unit.x > world.width() * 7) {
                unit.kill()
            }
            if (unit.moving()) unit.lookAt(unit.vel().angle())
        }
    }
}
suspend fun nextWave(){
    waves++
    state.rules.defaultTeam.rules().blockDamageMultiplier = (waves / 10f).coerceAtLeast(1.2f)
    state.rules.defaultTeam.rules().blockHealthMultiplier = (waves / 10f).coerceAtLeast(1.5f) * 2
    broadcast("[red]波次 {waves}, 阶段 {stage}".with("waves" to waves, "stage" to stage))
    if (waves == 11) {
        broadcast("[red]敌方单位受到终焉铭能影响 伤害 移速 增加！".with())
    }
    if (waves == 21) {
        broadcast("[red]敌方单位受到终焉铭能影响 伤害 移速 增加！\n王座加入战场！".with())
    }
    if (waves == 31) {
        broadcast("[red]敌方单位受到终焉铭能影响 伤害 血量 大幅增加！".with())
    }
    if (waves == 41) {
        broadcast("[red]敌方单位受到终焉铭能影响 血量 大幅增加！".with())
    }
    val eachPlayerCoins = (teamCoins / Groups.player.size().coerceAtLeast(1))
    Groups.player.forEach {
        it.data.coins += eachPlayerCoins
    }
    teamCoins = 0
    if (waves % 5 == 0) {
        createAirdrop()
    }
    if (waves > 20) repeat(waves - 19){
        createEnemy(UnitTypes.reign)
    }
    enemyCoins += ((waves * 3f).pow(2.2f) * (Groups.player.size() / 2f).coerceAtLeast(1f).coerceAtMost(10f)).toInt()
    waveStartTime = (Time.millis() + waveDelay).toLong()
    while (waveStartTime >= Time.millis()) {
        if (waveOver){
            waveStartTime -= 500L
            teamCoins += waves * waves / 5
        }
        delay(100)
    }
    if (waves < 50)
        nextWave()
    else {
        broadcast("[red]天灾-终末之时 完全降临！\n撑到完全击溃终焉铭能！\n敌方不再会增加残余！".with())
        enemyCoins += ((waves * 3f).pow(2.2f) * (Groups.player.size() / 2f).coerceAtLeast(1f).coerceAtMost(10f)).toInt() * 3
        waves = 75
        while (!waveOver) {
            yield()
        }
        broadcast("[cyan]天灾-终末之时 已被击溃！".with())
        if (MapManager.current.id == 15006) {
            Groups.player.forEach {
                val profile = PlayerData[it.uuid()].profile
                if (profile != null)
                    achievement.finishAchievement(profile, "终末之时通关", amount, true)
            }
        }
        delay(10_000)
        state.gameOver = true
        Events.fire(EventType.GameOverEvent(state.rules.defaultTeam))
    }
}

fun createAirdrop(block: Block){
    val u = UnitTypes.mega.spawn(Team.get(42), 32f, worldCenterY + Random.nextInt(-320, 320))
    (u as Payloadc).apply{
        addPayload(BuildPayload(block, state.rules.defaultTeam))
        maxHealth(Float.MAX_VALUE)
        health(maxHealth())
    }
}

suspend fun createAirdrop(){
    val t1List = buildList { t1blockRandom.forEach { (t, u) -> repeat(u) { add(t) } } }
    val t2List = buildList { t2blockRandom.forEach { (t, u) -> repeat(u) { add(t) } } }
    val t3List = buildList { t3blockRandom.forEach { (t, u) -> repeat(u) { add(t) } } }
    val t1num = (waves * 3).coerceAtMost(50)
    val t2num = waves / 5 * 3
    broadcast("[cyan]<穿梭> 新的铭能具象即将空投至中央".with())
    repeat(t2num) {
        delay(300L)
        createAirdrop(t2List.random())
    }
    repeat(t1num) {
        delay(50L)
        createAirdrop(t1List.random())
    }
    if (waves % 10 == 0)
        createAirdrop(t3List.random())
}

onEnable {
    contextScript<coreMindustry.ContentsTweaker>().addPatch("TE",contentPatch)
    contextScript<coreMindustry.UtilMapRule>().apply {
        arrayOf(UnitTypes.atrax, UnitTypes.spiroct, UnitTypes.arkyid, UnitTypes.toxopid).forEach {
            registerMapRule(
                it::aiController
            ) { Prov<UnitController> { ArenaAI() }}
        }
        registerMapRule(
            UnitTypes.poly::aiController
        ) { Prov<UnitController> { SwarmAI() }}
        registerMapRule(
            UnitTypes.mega::aiController
        ) { Prov<UnitController> { ReinforcementAI() }}

        arrayOf(UnitTypes.reign, UnitTypes.scepter).forEach {
            registerMapRule(
                it::aiController
            ) { Prov<UnitController> { ArenaAI() }}
        }
    }
    loop(Dispatchers.game){
        state.rules.modeName = "[white]终末之时|$stageName[white]|$waves"
        Call.setRules(state.rules)
        delay(100L)
    }
    state.rules.apply{
        waveTimer = false
        unitCap = 100
        waveTeam = Team.malis
        canGameOver = false
        defaultTeam.rules().cheat = true
    }
    if (!state.rules.defaultTeam.cores().isEmpty){
        state.rules.defaultTeam.cores().forEach { it.kill() }
    }
    loop(Dispatchers.game){
        Groups.player.forEach {
            Call.setHudText(it.con, buildString {
                appendLine("-----$stageName[white]-----")
                appendLine("[yellow]波数:[white]$waves / ${stage  * 10}")
                if (waveStartTime > Time.millis()) appendLine("[yellow]下一波倒计时${(waveStartTime - Time.millis()) / 1000}s${if(waveOver) ">>>" else ""}")
                appendLine("[yellow]团队铭能:[white]${teamCoins}[yellow](每波结束下发)")
                appendLine("[yellow]个人铭能:[white]${it.data.coins}[yellow](用于购买单位)")
                appendLine("[red]终焉铭能残余:[white]${enemyCoins}")
                append("[cyan]输入[lime]/shop[cyan]或者[lime]/商店[cyan]购买单位")
            })
        }
        yield()
    }
    loop(Dispatchers.game){
        Groups.player.forEach { p ->
            launch(Dispatchers.game){
                p.data.artifacts.forEach { it.timerEffect?.invoke(p) }
            }
        }
        delay(1000)
    }
    loop(Dispatchers.game){
        if (waveOver)
            Groups.player.forEach {
                if (it.unit().maxHealth <= 1)
                    it.respawn()
                if (!it.data.gived){
                    it.data.coins = 400
                    it.data.gived = true
                }
            }
        yield()
    }
    launch(Dispatchers.game){
        val startRespawnTime = Time.millis()
        while (Time.timeSinceMillis(startRespawnTime) <= 20_000) {
            yield()
        }
        nextWave()
    }
    launch(Dispatchers.game){
        delay(10000)
        while (true) {
            unitCostsE.keys.reversed().forEach {
                it.trySummonEnemy()
            }
            if (state.rules.defaultTeam.data().unitCount == 0 && !state.gameOver) {
                if (MapManager.current.id == 15006 && waves > 40) {
                    Groups.player.forEach {
                        val profile = PlayerData[it.uuid()].profile
                        if (profile != null)
                            achievement.finishAchievement(profile, "终末之时40波击破", amount / 4, true)
                    }
                }
                if (MapManager.current.id == 15006 && waves in 30..39) {
                    Groups.player.forEach {
                        val profile = PlayerData[it.uuid()].profile
                        if (profile != null)
                            achievement.finishAchievement(profile, "终末之时30波击破", amount / 8, true)
                    }
                }
                if (MapManager.current.id == 15006 && waves in 20..29) {
                    Groups.player.forEach {
                        val profile = PlayerData[it.uuid()].profile
                        if (profile != null)
                            achievement.finishAchievement(profile, "终末之时20波击破", amount / 10, true)
                    }
                }
                state.gameOver = true
                Events.fire(EventType.GameOverEvent(state.rules.waveTeam))
                break
            }
            yield()
        }
    }
}

listen<EventType.UnitDestroyEvent> {
    val unit = it.unit
    if (unit.team == state.rules.waveTeam){
        teamCoins += unitCostsE[unit.type]?.times(7)?.times((Groups.player.size() / 10f).coerceAtLeast(1f))?.toInt() ?: 0
    }
    if (unit.team == state.rules.defaultTeam && unit.type != UnitTypes.poly && unit.type != UnitTypes.crawler && waves <= 50){
        enemyCoins += unitCosts[unit.type]?.div(10)?.div((Groups.player.size() / 4f).coerceAtLeast(1f))?.toInt() ?: 0
    }
}

listen<EventType.UnitDamageEvent> { e ->
    val player = e.unit.player ?: return@listen
    player.data.artifacts.forEach {
        it.defEffect?.invoke(Pair(player, e))
    }
}

listen<EventType.UnitDamageEvent> { e ->
    if (e.bullet.owner !is Unit) return@listen
    val player = (e.bullet.owner as Unit).player ?: return@listen
    player.data.artifacts.forEach {
        it.attackEffect?.invoke(Pair(player, e))
    }
}

suspend fun Player.shopMenu(page: Int = Random.nextInt(0,6)){
    val pageN = if (page % 7 >= 0) page % 7 else 6
    menu.sendMenuBuilder<kotlin.Unit>(
        this, 30_000, "[green]商店！",
        """
                [yellow]购买单位！
            """.trimIndent()
    ) {
        val units = unitCosts.keys.toList().subList(pageN * 5, pageN * 5 + 5)
        add(buildList {
            units.subList(0, 3).forEach {
                add("${it.emoji()}\n${unitCosts[it]!!}" to {
                    if (data.coins >= unitCosts[it]!!) {
                        data.coins -= unitCosts[it]!!
                        createUnit(it)
                        shopMenu(pageN)
                    } else {
                        sendMessage("[red]金钱不足")
                    }
                })
            }
        })
        add(buildList {
            units.subList(3, 5).forEach {
                add("${it.emoji()}\n${unitCosts[it]!!}" to {
                    if (data.coins >= unitCosts[it]!!) {
                        data.coins -= unitCosts[it]!!
                        createUnit(it)
                        shopMenu(pageN)
                    } else {
                        sendMessage("[red]金钱不足")
                    }
                })
            }
        })
        add(listOf(
            "${unitCosts.keys.toList()[(if (pageN - 1 >= 0) pageN - 1 else 6 ) * 5].emoji()}<-" to { shopMenu(pageN - 1) },
            "->${unitCosts.keys.toList()[(if (pageN + 1 < 7) pageN + 1 else 0) * 5].emoji()}" to { shopMenu(pageN + 1) }
        ))
    }
}

command("shop", "购买单位") {
    type = CommandType.Client
    aliases = listOf("商店")
    body {
        val player = player!!
        launch(Dispatchers.game) {
            player.shopMenu()
        }
    }
}
command("wave", "设置波次") {
    permission = id.replace("/", ".")
    body {
        if (arg.isEmpty()) returnReply("No".with())
        waves = arg.first().toInt()
    }
}
command("coin", "增加金钱") {
    permission = id.replace("/", ".")
    body {
        player!!.data.coins += arg.first().toInt()
    }
}
command("coinAll", "增加金钱") {
    permission = id.replace("/", ".")
    body {
        val amount = arg.first().toInt()
        Groups.player.forEach { it.data.coins += amount }
    }
}