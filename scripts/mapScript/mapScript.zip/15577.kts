@file:Depends("coreMindustry/contentsTweaker", "修改核心单位,单位属性")

package mapScript

import arc.math.geom.Geometry
import arc.math.geom.Point2
import arc.util.Time
import cf.wayzer.placehold.PlaceHoldApi.with
import coreLibrary.lib.util.loop
import coreMindustry.lib.broadcast
import coreMindustry.lib.game
import mindustry.Vars
import mindustry.content.Blocks
import mindustry.content.Items
import mindustry.content.StatusEffects
import mindustry.content.UnitTypes
import mindustry.game.Team
import mindustry.gen.Call
import mindustry.gen.Groups
import mindustry.gen.Posc
import mindustry.type.UnitType
import mindustry.world.blocks.storage.CoreBlock.CoreBuild
import org.intellij.lang.annotations.Language

/**@author xkldklp
 * https://mdt.wayzer.top/v2/map/15577/latest
 */
name = "RWD III"


/**
 * @return 无法找到合适位置，返回null
 */
fun UnitType.spawnAround(pos: Posc, team: Team, radius: Int = 10): mindustry.gen.Unit? {
    return create(team).apply {
        set(pos)
        val valid = mutableListOf<Point2>()
        Geometry.circle(tileX(), tileY(), radius) { x, y ->
            if (canPass(x, y) && (isGrounded || Vars.world.tile(x, y)?.floor()?.isDeep == false))
                valid.add(Point2(x, y))
        }
        val r = valid.randomOrNull() ?: return null
        x = r.x * Vars.tilesize.toFloat()
        y = r.y * Vars.tilesize.toFloat()
        add()
    }
}

val contentPatch
    @Language("JSON5")
    get() = """
{
  "unit": {
    "risso" : {
      "flying": true
    },
    "bryde" : {
      "flying": true
    },
    "sei" : {
      "flying": true
    },
    "omura" : {
      "flying": true
    },
  },
  "block": {
    "core-shard": {
      "unitType": "mono",
      "solid": false,
    },
    "core-bastion.health": 999999999
  }
}"""

data class TeamData(
    var score: Int = 0,
    var spawnPoint: Posc? = null,
) {
    lateinit var team: Team
}

val teamData by autoInit { mutableMapOf<Team, TeamData>() }
val Team.data
    get() = teamData.getOrPut(this) { TeamData() }
        .also { it.team = this }

var rounds = 0

val units = arrayOf(
    arrayOf(UnitTypes.nova, UnitTypes.dagger, UnitTypes.flare),
    arrayOf(UnitTypes.mace, UnitTypes.pulsar, UnitTypes.stell, UnitTypes.merui),
    arrayOf(UnitTypes.atrax, UnitTypes.horizon, UnitTypes.poly, UnitTypes.risso),
    arrayOf(UnitTypes.minke, UnitTypes.fortress, UnitTypes.quasar, UnitTypes.locus, UnitTypes.cleroi),
    arrayOf(UnitTypes.zenith, UnitTypes.mega, UnitTypes.bryde, UnitTypes.precept),
    arrayOf(UnitTypes.scepter, UnitTypes.vela, UnitTypes.antumbra, UnitTypes.vanquish, UnitTypes.tecta),
    arrayOf(UnitTypes.reign, UnitTypes.corvus, UnitTypes.sei),
    arrayOf(UnitTypes.omura, UnitTypes.conquer, UnitTypes.toxopid),
)

onEnable {
    contextScript<coreMindustry.ContentsTweaker>().addPatch("RWDIII", contentPatch)
    Vars.state.teams.getActive().remove(Team.crux.data())
    Vars.state.rules.apply {
        unitCap = 999
    }
    rounds = 0
    Vars.state.teams.getActive().forEach {
        it.cores.toArray().find { it.block == Blocks.coreShard }?.apply {
            it.team.data.spawnPoint = this
            kill()
        }
        it.cores.forEach {
            it.maxHealth = it.block.health.toFloat()
            it.health = it.block.health.toFloat()
        }
    }
    loop(Dispatchers.game) {
        Vars.state.teams.getActive().remove(Team.crux.data())
        Vars.state.rules.apply {
            mission = buildString {
                appendLine("回合数 $rounds 每3轮分数最低队将淘汰！")
                Vars.state.teams.getActive().sortedBy { it.team.data.score }.reversed().forEach {
                    appendLine("[#${it.team.color}]${it.team.name} 有 ${it.team.data.score} 分")
                }
            }
        }
        Call.setRules(Vars.state.rules)
        delay(1000L)
    }
    launch(Dispatchers.game) {
        delay(5_000L)
        loop(Dispatchers.game) {
            rounds++
            Vars.state.rules.blockHealthMultiplier = rounds * 0.5f + 1f
            val roundUnits = buildList {
                repeat(rounds) {
                    if (units.getOrNull(it) != null) {
                        add(units[it])
                    }
                }
            }
            Vars.state.teams.getActive().toArray().filter { it.team.data.spawnPoint != null }.forEach {
                val rank = Vars.state.teams.getActive().sortedBy { it.team.data.score }.indexOf(it)
                val statusEffectList = buildList {
                    if (rounds != 1) {
                        if (rank <= 2) {
                            add(StatusEffects.overdrive)
                        }
                        if (rank <= 1) {
                            add(StatusEffects.overclock)
                        }
                        if (rank <= 0) {
                            add(StatusEffects.boss)
                        }
                    }
                }
                repeat(rounds * 5) { _ ->
                    roundUnits.random().random().spawnAround(it.team.data.spawnPoint!!, it.team)?.apply {
                        statusEffectList.forEach { s ->
                            apply(s, 9999999f)
                        }
                    }
                }
                it.core().items.add(Items.copper, 500)
                it.core().items.add(Items.lead, 500)
                it.team.data.spawnPoint!!.tileOn().setNet(Blocks.coreShard, it.team, 0)
            }
            val leftTeams = Vars.state.teams.getActive().toMutableSet()
            val defeatTeams = mutableListOf<mindustry.game.Teams.TeamData>()

            val startTime = Time.millis()

            val blockHealthMultiplierBak = Vars.state.rules.blockHealthMultiplier
            val unitDamageMultiplierBak = Vars.state.rules.unitDamageMultiplier
            delay(1000L)
            broadcast("新轮次开始！".with())
            while (true) {
                leftTeams.forEach {
                    if (it !in defeatTeams && (Groups.unit.filter { u -> u.team == it.team }.none { !it.spawnedByCore } || it.cores.size <= 1)) {
                        Groups.unit.filter { u -> u.team == it.team }.forEach {
                            it.apply(StatusEffects.corroded, 999999f)
                            it.apply(StatusEffects.melting, 999999f)
                            it.apply(StatusEffects.burning, 999999f)
                            it.apply(StatusEffects.disarmed, 999999f)
                            it.apply(StatusEffects.unmoving, 999999f)
                            it.health /= 4
                            it.maxHealth /= 4
                        }
                        defeatTeams.add(it)
                    }
                }
                if (leftTeams.toSet().filter { it !in defeatTeams }.size <= 1) {
                    break
                }
                if (Time.millis() - startTime >= 240_000) {
                    Groups.unit.forEach {
                        it.apply(StatusEffects.corroded, 999999f)
                    }
                    Vars.state.rules.blockHealthMultiplier = blockHealthMultiplierBak / 2f
                    Vars.state.rules.unitDamageMultiplier = unitDamageMultiplierBak * 2f
                }
                yield()
            }
            Vars.state.rules.blockHealthMultiplier = blockHealthMultiplierBak
            Vars.state.rules.unitDamageMultiplier = unitDamageMultiplierBak

            defeatTeams.forEach {
                it.team.data.score += defeatTeams.indexOf(it) + 1
            }
            val winner = leftTeams.toSet().filter { it !in defeatTeams }.firstOrNull()
            if (winner != null) {
                winner.team.data.score += Vars.state.teams.getActive().size
            }
            broadcast("轮次结束！".with())

            if (rounds % 3 == 0) {
                val team = Vars.state.teams.getActive().minBy { it.team.data.score }
                broadcast("[#{teamColor}]{team} 淘汰！".with("teamColor" to team.team.color,"team" to team.team))
                team.destroyToDerelict()
            }
            delay(10_000L)
        }
    }
}