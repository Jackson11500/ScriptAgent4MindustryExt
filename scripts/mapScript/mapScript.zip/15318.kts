@file:Depends("coreMindustry/utilNext", "调用菜单")
@file:Depends("coreMindustry/contentsTweaker", "修改核心单位,单位属性")
@file:Depends("coreMindustry/utilMapRule", "修改单位ai")
@file:Suppress("unused", "unused", "PropertyName", "PropertyName", "PropertyName", "PropertyName", "PropertyName",
    "PropertyName", "PropertyName", "PropertyName", "PropertyName", "PropertyName", "PropertyName", "PropertyName",
    "KotlinDeprecation", "KotlinDeprecation", "KotlinDeprecation", "Deprecated"
)

package mapScript

import arc.graphics.Color
import arc.math.geom.Geometry
import arc.math.geom.Point2
import arc.math.geom.Vec2
import arc.util.Time
import coreLibrary.lib.util.loop
import coreLibrary.lib.with
import coreMindustry.lib.*
import mindustry.Vars
import mindustry.content.Blocks
import mindustry.content.Fx
import mindustry.content.StatusEffects
import mindustry.content.UnitTypes
import mindustry.entities.Units
import mindustry.game.EventType
import mindustry.game.Team
import mindustry.gen.*
import mindustry.type.UnitType
import mindustry.world.Tile
import mindustry.world.blocks.logic.MessageBlock.MessageBuild
import org.intellij.lang.annotations.Language
import kotlin.math.min
import kotlin.random.Random


/**@author xkldklp
 * https://mdt.wayzer.top/v2/map/15318/latest
 */
name = "bedWars"

val menu = contextScript<coreMindustry.UtilNext>()

/**
 * @return 无法找到合适位置，返回null
 */
fun UnitType.spawnAround(pos: Posc, team: Team, radius: Int = 10): mindustry.gen.Unit? {
    return create(team).apply {
        set(pos)
        val valid = mutableListOf<Point2>()
        Geometry.circle(tileX(), tileY(), radius) { x, y ->
            if (canPass(x, y) && (isGrounded || Vars.world.tile(x, y)?.floor()?.isDeep == false))
                valid.add(Point2(x, y))
        }
        val r = valid.randomOrNull() ?: return null
        x = r.x * Vars.tilesize.toFloat()
        y = r.y * Vars.tilesize.toFloat()
        add()
    }
}

val contentPatch
    @Language("JSON5")
    get() = """
{
  "unit": {
    "dagger.health": 40,
    "dagger.weapons.0.bullet.damage": 0,
    "emanate.weapons.0.bullet.maxRange": 0,
  },
  "block": {
    "tar.speedMultiplier": 1.5,
    "tar.drownTime": 45,
    "tar.statusDuration": 2,
    "junction.health": 30,
    "core-shard": {
      "health": 100,
      "unitType": "emanate",
    },
    "core-foundation": {
      "health": 300,
      "unitType": "emanate",
    },
    "core-bastion": {
      "health": 500,
      "unitType": "emanate",
    },
    "core-nucleus": {
      "health": 800,
      "unitType": "emanate",
    },
    "core-citadel": {
      "health": 1100,
      "unitType": "emanate",
    },
    "core-acropolis": {
      "health": 1500,
      "unitType": "emanate",
    }
  },
  "status": {
    "tarred.speedMultiplier": 1,
    "tarred.damage": 0.05,
    "burning.damage": 0.03
  }
}"""

UnitTypes.emanate
StatusEffects.burning

class ScriptItem(
    val name: String,
    val desc: String,

    val cost: Int = 0,
    val drop: Boolean = false,

    val effect: (Player.() -> Unit)? = null,

    val timerEffect : (Player.() -> Unit)? = null,

    val attackEffect: (Pair<Player, mindustry.gen.Unit>.() -> Unit)? = null,
    val range: Float = 0f,
    val power: Float = 0f,

    val defEffect: (Pair<Player, mindustry.gen.Unit>.() -> Unit)? = null,
    val armor: Float = 0f,

    val throwEffect: (Pair<Player, Vec2>.() -> Unit)? = null,
    val throwRange: Float = 0f,
    val speed: Float = 0f,

    val activeEffect: (Player.() -> Unit)? = null,

    val minePower: Float = 0f,

    val deadKeep: Boolean = false,
)

/**
 * gray
 * lightgray
 * white
 * cyan
 * purple - 普通5阶物品 orange - 特殊5阶物品
 * red - 6阶物品
 */
class ScriptItems(
    val lv1Coin: ScriptItem = ScriptItem("[gray]不纯铭晶", "[yellow]低纯度的铭能凝聚,可以具象出基础物品\n[white]蕴含4点铭能", 4, true , power = 0.5f, range = 12 * 8f),
    val lv2Coin: ScriptItem = ScriptItem("[lightgray]破损铭晶", "[yellow]破损的铭晶,起码比不纯品蕴含的铭能多\n[white]蕴含4点铭能", 12, true, power = 1f, range = 12 * 8f),
    val lv3Coin: ScriptItem = ScriptItem("[white]铭能晶体", "[yellow]铭晶,可以具象出大部分物品\n[cyan]使用后回复2点HP\n[white]蕴含4点铭能", 48, true, activeEffect = fun Player.() { unit().heal(2f) }, power = 1.5f, range = 12 * 8f),
    val lv4Coin: ScriptItem = ScriptItem("[cyan]高纯铭晶", "[yellow]纯度相当高的铭晶,可以具象左右战场的高级物品\n[cyan]使用后回复5点HP\n[white]蕴含4点铭能", 320, true, activeEffect = fun Player.() { unit().heal(5f) }, power = 1.5f, range = 12 * 8f),

    val block1: ScriptItem = ScriptItem("[gray]搭路石", "[yellow]用于在虚空之上穿梭(自动搭路)\n${Iconc.blockJunction}", 1),
    val block2: ScriptItem = ScriptItem("[lightgray]坚固的搭路石", "[yellow]用于在虚空之上穿梭(自动搭路),更加坚固\n${Iconc.blockLiquidJunction}", 4),
    val block3: ScriptItem = ScriptItem("[lightgray]挡路石", "[yellow]阻挡你的敌人\n${Iconc.blockCopperWall}", 8),
    val block4: ScriptItem = ScriptItem("[white]坚固的挡路石", "[yellow]阻挡你的敌人,更加坚固\n${Iconc.blockTitaniumWall}", 64),
    val block5: ScriptItem = ScriptItem("[white]可控挡路石", "[yellow]阻挡你的敌人,可操控开关\n${Iconc.blockDoor}", 64),
    val block6: ScriptItem = ScriptItem("[cyan]偏移", "[yellow]阻挡你的敌人,阻止附近的敌对攻击伤害\n${Iconc.blockRadar}", 320),

    val weapon1: ScriptItem = ScriptItem("[lightgray]星辰碎片", "[yellow]组成星辰铭的碎片,铭能凝聚而成,无特殊效果\n[white]攻击：3|范围：12", 60, power = 3f, range = 12 * 8f),
    val weapon2: ScriptItem = ScriptItem("[white]空白星铭", "[yellow]没有刻印任何特殊铭能的星辰铭\n[white]攻击：5|范围：12", 240, power = 5f, range = 12 * 8f),
    val weapon3: ScriptItem = ScriptItem("[cyan]长刀", "[yellow]刻印着<长刀>的星辰铭,攻击范围增加。\n[white]攻击：4|范围：14", 480, power = 4f, range = 14 * 8f),
    val weapon4: ScriptItem = ScriptItem("[cyan]裂变", "[yellow]刻印着<裂变>的星辰铭,攻击增加。\n[white]攻击：6|范围：12", 480, power = 6f, range = 12 * 8f),
    val weapon5: ScriptItem = ScriptItem("[cyan]粘液", "[yellow]刻印着<粘液>的星辰铭。\n[cyan]攻击时触发：击中后一秒造成孢子减速(-20%移速)1.5s\n[white]攻击：4|范围：12", 960, power = 4f, range = 12 * 8f,
        attackEffect = fun Pair<Player, mindustry.gen.Unit>.() { launch(Dispatchers.game) {
            delay(1000)
            second.apply(StatusEffects.sporeSlowed, 1.5f * 60f)
        }}
    ),
    val weapon6: ScriptItem = ScriptItem("[purple]无尽之剑", "[yellow]无尽之剑,可以抑制刻印重生。\n[cyan]攻击时触发：重生倒计时变为15s\n[white]攻击：6|范围：12", 960, power = 6f, range = 12 * 8f,
        attackEffect = fun Pair<Player, mindustry.gen.Unit>.() {
            second.player?.data?.respawnTime = Time.millis() + 15_000
        }
    ),
    val weapon7: ScriptItem = ScriptItem("[purple]烈阳", "[yellow]刻印着<烈阳>[lightgray]火焰附加[yellow]的星辰铭。\n[cyan]攻击时触发：造成燃烧1.5s\n[white]攻击：3|范围：12", 960, power = 3f, range = 12 * 8f,
        attackEffect = fun Pair<Player, mindustry.gen.Unit>.() {
            second.apply(StatusEffects.burning, 1.5f * 60f)
        }
    ),
    val weapon8: ScriptItem = ScriptItem("[purple]毁灭", "[yellow]刻印着<毁灭>的星辰铭,对近距离单位造成致命伤害。\n[white]攻击：10|范围：6", 960, power = 10f, range = 4 * 8f),

    val test1: ScriptItem = ScriptItem("[orange]闪耀之光", "[yellow]提供近乎无限的铭能", 999999999, deadKeep = true),
    val test2: ScriptItem = ScriptItem("[orange]无尽之殇", "[yellow]一剑,斩破时间", 0, power = 999f, range = 12 * 8f, deadKeep = true),
    val test3: ScriptItem = ScriptItem("[orange]永恒之殇", "[yellow]另一剑,斩破空间", 0, power = 10f, range = 999 * 8f, deadKeep = true),
    val test4: ScriptItem = ScriptItem("[orange]不灭之护", "[yellow]坚固无比,永恒不灭", 0, armor = 49f, deadKeep = true),
) {
    fun coins(): Array<ScriptItem> {
        return arrayOf(
            lv1Coin,
            lv2Coin,
            lv3Coin,
            lv4Coin,
            test1,
        )
    }
}

val scriptItems = ScriptItems()

class DropItem(
    val item: ScriptItem,
    var amount: Int,
    var disappearTime: Long,
    var dropLocation: Vec2,
) {
    fun update(appearTime: Float = 1.013f) {
        if (!isValid()) return
        val target = dropItems.find { it.isValid() && it.item == item && it.dropLocation.within(dropLocation, 1.2f * 8f) && it != this}
        if (target != null) {
            target.amount += amount
            target.disappearTime = min(target.disappearTime, disappearTime)
            disappearTime = 0
        } else {
            if (Groups.player.filter { it.within(dropLocation, 1.2f * 8f) && it.unit().type == UnitTypes.dagger }.isNotEmpty())
                Groups.player.filter { it.within(dropLocation, 1.2f * 8f) && it.unit().type == UnitTypes.dagger }.random().apply {
                    data.items[item] = data.items.getOrDefault(item, 0) + amount
                    disappearTime = 0
                    return
                }
            Groups.player.filter { it.within(dropLocation, 40 * 8f) && Vars.fogControl.isVisible(it.team(), dropLocation.x, dropLocation.y) }.forEach {
                Call.label(it.con, buildString {
                    appendLine("${item.name} * $amount")
                    append("${((disappearTime - Time.millis()) / 1000f).format(1)}s")
                }, appearTime, dropLocation.x, dropLocation.y)
            }
        }
    }
}
val dropItems by autoInit { mutableSetOf<DropItem>() }

fun DropItem.isValid(): Boolean {
    return disappearTime >= Time.millis()
}

class SpawnPoint(
    val item: ScriptItem,
    var cooldown: Int,
    var location: Vec2,
    var lastSpawnTime: Long = 0
)
val spawnPoints by autoInit { mutableSetOf<SpawnPoint>() }

data class PlayerData(
    val items: MutableMap<ScriptItem, Int> = mutableMapOf(),
    var respawnTime: Long = 0,
    var attackCooldown: Long = 0
) {
    lateinit var player: Player

    fun reset(unit: mindustry.gen.Unit, respawnNeedTime: Long = 5_000){
        if (unit.data.reseted) return
        unit.data.reseted = true
        items.forEach { item ->
            if (item.key.deadKeep || item.value <= 0) return@forEach
            if (item.key.drop) {
                val times = min(item.value, 15)
                val exAmount = item.value % times
                repeat(times) {
                    dropItems.add(DropItem(item.key,
                        item.value / times + (if (exAmount - it + 1 > 0) 1 else 0),
                        Time.millis() + 60_000,
                        Vec2(unit.x + Random.nextInt(-24, 24), unit.y + Random.nextInt(-24, 24))))
                }
            }
            items[item.key] = 0
        }
        unit.kill()
        if (!player.team().data().cores.isEmpty)
            respawnTime = Time.millis() + respawnNeedTime
    }

    fun damage(range: Float): Float? {
        val weapons = items.filter { it.value > 0 }.keys.toList().filter { it.power != 0f && it.range >= range }
        return if (weapons.isEmpty()) null else weapons.maxOf { it.power }
    }

    /**
     * 1.攻击者所有攻击特效触发
     * 2.防御者所有防御特效触发
     * 3.结算伤害 伤害 * (1 - 防御者最高护甲物品(max 49) / 50)
     */

    fun damage(from: Player, damage: Float) {
        if (from.data.items.filter { it.value > 0 }.isNotEmpty()) {
            from.data.items.filter { it.value > 0 }.forEach {
                it.key.attackEffect?.invoke(Pair(from, player.unit()))
            }
        }
        "a".replace("-","")
        if (items.filter { it.value > 0 }.isNotEmpty()) {
            items.filter { it.value > 0 }.forEach {
                it.key.defEffect?.invoke(Pair(from, player.unit()))
            }
        }
        val unit = player.unit()
        if (items.filter { it.value > 0 && it.key.armor > 0 }.isNotEmpty()) {
            unit.health -= damage * (1 - items.filter { it.value > 0 }.keys.maxOf { it.armor }.coerceAtMost(49f) / 50f)
        } else {
            unit.health -= damage
        }
        if (unit.health < 0) {
            broadcast((arrayOf(
                "{player} [white]被 {killer} [white]击杀！",
                "{player} [white]被 {killer} [white]点爆！",
                "{player} [white]在与 {killer} [white]的决斗中落败！",
                "{player} [white]无法战胜 {killer} [white]",
                "{player} [white]死于 {killer} [white]之手！"
            ).random() + "{finalKill}").with("player" to player,"killer" to from, "finalKill" to if (player.team().data().cores.isEmpty) "[cyan]最终击杀！" else ""))
        }
    }
}
val playerData by autoInit { mutableMapOf<String, PlayerData>() }
val Player.data
    get() = playerData.getOrPut(uuid()) { PlayerData() }
        .also { it.player = this }

data class UnitData(
    var player: Player? = null,
    var reseted: Boolean = false
) {
    lateinit var unit: mindustry.gen.Unit
    /**
     * 1.攻击者所有攻击特效触发
     * 2.结算伤害
     */

    fun damage(from: Player, damage: Float) {
        if (from.data.items.filter { it.value > 0 }.isNotEmpty()) {
            from.data.items.filter { it.value > 0 }.forEach {
                it.key.attackEffect?.invoke(Pair(from, unit))
            }
        }
        unit.health -= damage
    }
}
val unitData by autoInit { mutableMapOf<mindustry.gen.Unit, UnitData>() }
val mindustry.gen.Unit.data
    get() = unitData.getOrPut(this) { UnitData() }
        .also { it.unit = this }

fun Float.format(i: Int = 2): String {
    return "%.${i}f".format(this)
}

fun mindustry.gen.Unit.buildHealthBar(length: Int = 20): String {
    return buildString {
        repeat(length) {
            append("${
                when {
                    health > it + length -> "[yellow]"
                    health > it -> "[green]"
                    else -> "[red]"
                }
            }|")
        }
    }
}

onEnable {
    contextScript<coreMindustry.ContentsTweaker>().addPatch("BW",contentPatch)
    Vars.state.rules.apply {
        bannedBlocks.clear()
        blockWhitelist = true
        cleanupDeadTeams = false
        hideBannedBlocks = true
        possessionAllowed = false
    }
    Call.setRules(Vars.state.rules)
    loop(Dispatchers.game) {
        Vars.state.rules.waveTeam.data().getBuildings(Blocks.worldMessage).forEach {
            it as MessageBuild
            Call.sendMessage("---资源点注册---\n${it.config()}")
            if (it.config().startsWith("资源生成点")) {
                var level: Int? = null
                var cooldown: Int? = null
                it.config().split(";").forEach a@{
                    if (it.split(":").size != 2) return@a
                    val first = it.split(":").first()
                    val second = it.split(":")[1]
                    if (first == "资源等级")
                        level = second.toIntOrNull() ?: 1
                    if (first == "生产冷却")
                        cooldown = second.toIntOrNull() ?: 1
                }
                if (level == null || cooldown == null) return@forEach
                spawnPoints.add(SpawnPoint(
                    when (level) {
                        1 -> scriptItems.lv1Coin
                        2 -> scriptItems.lv2Coin
                        3 -> scriptItems.lv3Coin
                        4 -> scriptItems.lv4Coin
                        else -> scriptItems.lv1Coin
                    },
                    cooldown!!,
                    Vec2(it.x, it.y)
                ))
                it.kill()
            }
        }
        delay(1000L)
    }
    loop(Dispatchers.game) {
        spawnPoints.forEach {
            if (Time.timeSinceMillis(it.lastSpawnTime) >= it.cooldown) {
                it.lastSpawnTime = Time.millis()
                dropItems.add(DropItem(it.item, 1, Time.millis() + 60_000, Vec2(it.location.x + Random.nextInt(-16 , 16), it.location.y + Random.nextInt(-16 , 16))))
            }
            Call.label(buildString {
                appendLine("[yellow]资源生成点")
                appendLine("${it.item.name}[white]${(it.cooldown / 1000f).format(1)}s")
                append("[cyan]${Iconc.blockMechanicalDrill}${((it.cooldown - Time.timeSinceMillis(it.lastSpawnTime)) / 1000f).format(1)}s")
            }, 1.013f, it.location.x, it.location.y)
        }
        dropItems.forEach {
            it.update(0.513f)
        }
        delay(250L)
    }
    loop(Dispatchers.game) {
        Groups.player.forEach { p ->
            Call.setHudText(p.con, buildString {
                if (p.unit().type != UnitTypes.dagger && Time.millis() >= p.data.respawnTime && !p.team().data().cores.isEmpty) {
                    UnitTypes.dagger.spawnAround(p.team().cores().random(), p.team())?.apply {
                        p.unit(this)
                        data.player = p
                        apply(StatusEffects.disarmed, Float.POSITIVE_INFINITY)
                    }
                }
                if (p.unit().type == UnitTypes.dagger) {
                    appendLine(p.unit().buildHealthBar())
                    appendLine("[red]♥[white]${p.unit().health}")
                    appendLine("-\uE81E背包\uE81E--")
                    if (p.data.items.filter { it.value > 0 }.isEmpty()) append("[lightgray]空") else append("[violet]|")
                    var index = 0
                    p.data.items.filter { it.value > 0 }.forEach {
                        if (index % 2 == 0 && index != 0) {
                            appendLine()
                            append("[violet]|")
                        }
                        append("${it.key.name} * ${it.value}")
                        append("[violet]|")
                        index++
                    }
                } else {
                    if (p.team().data().cores.isEmpty) {
                        appendLine("[red]队伍所有可以用于刻印的核心已被破坏")
                        append("[red]你将无法重生！")
                    } else {
                        appendLine("[red]你已死亡 等待重生")
                        append("[green]${((p.data.respawnTime - Time.millis()) / 1000f).format(1)}s")
                    }
                }
            })
        }
        delay(500L)
    }
    loop(Dispatchers.game) {
        Groups.unit.forEach {
            if (it.data.player != null && it.player?.data?.player != it.data.player) {
                broadcast((arrayOf(
                    "{player} [white]选择死亡。",
                    "{player} [white]自爆了。",
                    "{player} [white]变成了苦力怕。",
                    "{player} [white]灵魂离体。"
                ).random() + "{finalKill}").with("player" to it.data.player!!.name, "finalKill" to if (it.data.player!!.team().data().cores.isEmpty) "[cyan]最终击杀！" else ""))
                it.data.player!!.data.reset(it)
            }
        }
        yield()
    }
}

val playerLastTapTile by autoInit { mutableMapOf<String, Pair<Tile, Int>>() }

listen<EventType.TapEvent> {
    val player = it.player
    if (player.dead()) return@listen
    val targets = buildList {
        /*Units.nearby(null, it.player.unit().aimX, it.player.unit().aimY, UnitTypes.dagger.hitSize) { u ->
            if (u.team != it.player.team() && u.within(it.player.unit(), it.player.data.items.filter { it.value > 0 }.keys.maxOf { it.range })) {
                add(u)
            }
        }

        if (player.con.mobile)*/
            Groups.unit.forEach { u ->
                if (u.team != it.player.team() && u.within(it.tile, 8f))
                    add(u)
            }
    }
    if (targets.isNotEmpty()){
        val target = targets.random()
        val length = target.dst(it.player.unit())
        var damage = it.player.data.damage(length) ?: return@listen
        if (it.player.data.attackCooldown >= Time.millis()) return@listen
        it.player.data.attackCooldown = Time.millis() + 500
        if (target.isPlayer) {
            target.player.data.damage(it.player, damage)
            if (target.player.data.items.filter { it.value > 0 && it.key.armor > 0 }.isNotEmpty()) {
                damage *= 1 - target.player.data.items.filter { it.value > 0 }.keys.maxOf { it.armor }.coerceAtMost(49f) / 50f
            }
        }
        else
            target.data.damage(it.player, damage)

        Call.effect(Fx.unitEnvKill, target.x, target.y, 0f, Color.red)
        Call.label("-${damage.format(1)}[red]♥", 2.013f, target.x + Random.nextInt(-8 , 8), target.y + Random.nextInt(-8 , 8))
        it.player.sendMessage("""
            -${damage.format(1)}[red]♥
            [white]${target.buildHealthBar()}
        """.trimIndent())
    } else {
        playerLastTapTile[player.uuid()] = it.tile to if (it.tile == (playerLastTapTile[player.uuid()]?.first ?: false)) (playerLastTapTile[player.uuid()]?.second?.plus(1) ?: 1) else 1

    }
}

listen<EventType.UnitDestroyEvent> {
    it.unit.player?.data?.reset(it.unit)
}

command("test", "CHEATER") {
    permission = id.replace("/", ".")
    body {
        when(arg.firstOrNull()?.toInt()) {
            1 -> player!!.data.items[scriptItems.test1] = 9999
            2 -> player!!.data.items[scriptItems.test2] = 1
            3 -> player!!.data.items[scriptItems.test3] = 1
            4 -> player!!.data.items[scriptItems.test4] = 1
            else -> returnReply("No".with())
        }

    }
}

